"use strict";(()=>{function c(o){return!Number.isFinite(o)||Number.isNaN(o)?1:Math.round((o+Number.EPSILON)*100)/100}function w(o){return c(o).toFixed(2)}var z=[{id:"speed.decrease",action:{type:"speed.decrease"},code:"KeyS",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"speed.increase",action:{type:"speed.increase"},code:"KeyD",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"speed.reset",action:{type:"speed.reset"},code:"KeyR",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"seek.rewind",action:{type:"seek.relative",seconds:-10},code:"KeyZ",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"seek.advance",action:{type:"seek.relative",seconds:10},code:"KeyX",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"speed.preferred.toggle",action:{type:"speed.preferred.toggle"},code:"KeyG",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"overlay.toggle",action:{type:"overlay.toggle"},code:"KeyV",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"marker.set",action:{type:"marker.set"},code:"KeyM",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"marker.jump",action:{type:"marker.jump"},code:"KeyJ",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"pip.toggle",action:{type:"pip.toggle"},code:"KeyP",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0},{id:"silence.skip.toggle",action:{type:"silence.skip.toggle"},code:"KeyK",ctrl:!1,alt:!1,shift:!1,meta:!1,enabled:!0}];function Z(o){if(!o||!(o instanceof HTMLElement))return!1;let e=o.tagName.toLowerCase();if(e==="input"||e==="textarea"||e==="select"||o.isContentEditable||o.contentEditable==="true"||o.getAttribute("contenteditable")==="true"||o.getAttribute("contenteditable")===""||o.closest?.("[contenteditable='true'], [contenteditable=''], [contenteditable]"))return!0;let t=o.getAttribute("role");return t==="textbox"||t==="searchbox"||t==="combobox"}var C=class{actionHandler;shortcuts;abortController=null;enabled=!0;constructor(e,t=z){this.actionHandler=e,this.shortcuts=[...t]}setShortcuts(e){this.shortcuts=[...e]}getShortcuts(){return[...this.shortcuts]}attach(e=window){this.detach(),this.abortController=new AbortController;let{signal:t}=this.abortController;e.addEventListener("keydown",i=>{this.enabled&&i instanceof KeyboardEvent&&(i.isComposing||Z(i.target)||this.handleKeyDown(i))},{capture:!0,signal:t})}handleKeyDown(e){for(let t of this.shortcuts){if(!t.enabled)continue;let i=t.code===e.code,r=t.ctrl===(e.ctrlKey||e.metaKey),n=t.alt===e.altKey,s=t.shift===e.shiftKey;if(i&&r&&n&&s){e.preventDefault(),e.stopPropagation(),this.actionHandler.execute(t.action);return}}}detach(){this.abortController&&(this.abortController.abort(),this.abortController=null)}};var $={schemaVersion:1,enabled:!0,defaultSpeed:1,preferredSpeed:1.8,speedStep:.1,rewindSeconds:10,advanceSeconds:10,rememberPlaybackSpeed:!1,audioBoolean:!0,startHidden:!1,lastSpeed:1,domainSpeeds:{},overlay:{enabled:!0,position:{xRatio:.02,yRatio:.02},opacity:.3,customCss:""},shortcuts:z,siteRules:[{id:"rule-meet",match:"meet.google.com",enabled:!1},{id:"rule-teams",match:"teams.microsoft.com",enabled:!1},{id:"rule-imgur",match:"imgur.com",enabled:!1}],compatibility:{fightAutomaticRateReset:!0}};function j(o){try{if(typeof o=="object"&&o!==null&&"hostname"in o)return(o.hostname||"").toLowerCase().trim();let e=String(o).trim();if(!e)return"";let t=e.includes("://")?e:`https://${e}`;return(new URL(t).hostname||"").toLowerCase().trim()}catch{return""}}function b(o,e){let t=o.toLowerCase().trim(),i=e.toLowerCase().trim();if(!t||!i)return!1;if(t===i||i===`www.${t}`||`www.${i}`===t)return!0;if(t.startsWith("*.")){let r=t.slice(2);if(i===r||i.endsWith(`.${r}`))return!0}return!1}function l(o,e,t){return Number.isNaN(o)?e<=1&&t>=1?1:e:Math.min(Math.max(o,e),t)}var x=class{settings;constructor(e){this.settings=e}updateSettings(e){this.settings=e}getMatchingRule(e){let t=e.toLowerCase().trim();for(let i of this.settings.siteRules)if(b(i.match,t))return i}resolveSiteConfig(e){let t=j(e),i=this.getMatchingRule(t);if(!this.settings.enabled)return{enabled:!1,overlayEnabled:!1,initialSpeed:1,preferredSpeed:this.settings.preferredSpeed,rememberSpeed:!1,matchingRule:i};if(i&&!i.enabled)return{enabled:!1,overlayEnabled:!1,initialSpeed:1,preferredSpeed:this.settings.preferredSpeed,rememberSpeed:!1,matchingRule:i};let r=this.settings.overlay.enabled;i&&typeof i.overlayEnabled=="boolean"&&(r=i.overlayEnabled);let n=this.settings.rememberPlaybackSpeed;i&&typeof i.rememberSpeed=="boolean"&&(n=i.rememberSpeed);let s=this.settings.defaultSpeed;n&&(this.settings.domainSpeeds&&typeof this.settings.domainSpeeds[t]=="number"?s=this.settings.domainSpeeds[t]:typeof this.settings.lastSpeed=="number"&&(s=this.settings.lastSpeed)),i&&typeof i.defaultSpeed=="number"&&(s=i.defaultSpeed);let a=this.settings.preferredSpeed;return i&&typeof i.preferredSpeed=="number"&&(a=i.preferredSpeed),{enabled:!0,overlayEnabled:r,initialSpeed:l(c(s),.07,16),preferredSpeed:l(c(a),.07,16),rememberSpeed:n,matchingRule:i}}};function M(o){return o instanceof HTMLMediaElement}function q(o){return!Number.isFinite(o.duration)||o.duration===1/0}var k=class{audioCtx=null;sourceNode=null;gainNode=null;currentGain=1;media;constructor(e){this.media=e}setGain(e){let t=Math.max(1,Math.min(5,e));this.currentGain=t,!(t<=1&&!this.audioCtx)&&(this.ensureGraph(),this.gainNode&&(this.gainNode.gain.value=t),this.audioCtx&&this.audioCtx.state==="suspended"&&this.audioCtx.resume().catch(()=>{}))}getGain(){return this.currentGain}ensureGraph(){if(!(this.audioCtx&&this.gainNode))try{let e=window,t=e.AudioContext||e.webkitAudioContext;if(!t)return;this.audioCtx=new t,this.sourceNode=this.audioCtx.createMediaElementSource(this.media),this.gainNode=this.audioCtx.createGain(),this.gainNode.gain.value=this.currentGain,this.sourceNode.connect(this.gainNode),this.gainNode.connect(this.audioCtx.destination)}catch(e){console.warn("[Velocity] AudioBooster Web Audio init warning:",e)}}destroy(){try{this.gainNode?.disconnect(),this.sourceNode?.disconnect(),this.audioCtx&&this.audioCtx.state!=="closed"&&this.audioCtx.close().catch(()=>{})}catch{}this.audioCtx=null,this.sourceNode=null,this.gainNode=null}};function U(o,e){try{o.preservesPitch=e}catch{}let t=o;"mozPreservesPitch"in t&&(t.mozPreservesPitch=e),"webkitPreservesPitch"in t&&(t.webkitPreservesPitch=e)}var A=class{media;options;audioCtx=null;sourceNode=null;analyserNode=null;timerId=null;silentSince=null;currentlySilent=!1;destroyed=!1;constructor(e,t){this.media=e,this.options={thresholdDb:t.thresholdDb??-45,minSilenceMs:t.minSilenceMs??500,checkIntervalMs:t.checkIntervalMs??50,onSilenceChange:t.onSilenceChange}}start(){this.destroyed||this.timerId!==null||(this.ensureGraph(),this.timerId=window.setInterval(()=>this.checkAudioLevel(),this.options.checkIntervalMs))}stop(){this.timerId!==null&&(window.clearInterval(this.timerId),this.timerId=null),this.silentSince=null,this.currentlySilent&&(this.currentlySilent=!1,this.options.onSilenceChange(!1))}ensureGraph(){if(!(this.audioCtx&&this.analyserNode))try{let e=window,t=e.AudioContext||e.webkitAudioContext;if(!t)return;this.audioCtx=new t,this.sourceNode=this.audioCtx.createMediaElementSource(this.media),this.analyserNode=this.audioCtx.createAnalyser(),this.analyserNode.fftSize=256,this.sourceNode.connect(this.analyserNode),this.analyserNode.connect(this.audioCtx.destination)}catch(e){console.warn("[Velocity] SilenceDetector audio graph setup warning:",e)}}checkAudioLevel(){if(this.destroyed||!this.analyserNode||this.media.paused)return;if(this.audioCtx&&this.audioCtx.state==="suspended"){this.audioCtx.resume().catch(()=>{});return}let e=new Float32Array(this.analyserNode.fftSize);this.analyserNode.getFloatTimeDomainData(e);let t=0;for(let a=0;a<e.length;a++){let h=e[a];t+=h*h}let i=Math.sqrt(t/e.length),n=(i>1e-5?20*Math.log10(i):-100)<this.options.thresholdDb,s=Date.now();n?this.silentSince===null?this.silentSince=s:!this.currentlySilent&&s-this.silentSince>=this.options.minSilenceMs&&(this.currentlySilent=!0,this.options.onSilenceChange(!0)):(this.silentSince=null,this.currentlySilent&&(this.currentlySilent=!1,this.options.onSilenceChange(!1)))}destroy(){this.destroyed=!0,this.stop();try{this.analyserNode?.disconnect(),this.sourceNode?.disconnect(),this.audioCtx&&this.audioCtx.state!=="closed"&&this.audioCtx.close().catch(()=>{})}catch{}this.audioCtx=null,this.sourceNode=null,this.analyserNode=null}};var T=class{media;abortController=new AbortController;events;audioBooster;preservesPitch=!0;silenceSkipEnabled=!1;silenceDetector=null;rateBeforeSilence=null;desiredRate;observedRate;lastSource="initial";markerTime=null;positionBeforeJump=null;previousRateBeforeReset=null;previousRateBeforePreferred=null;lastInteractionAt=Date.now();destroyed=!1;constructor(e,t=1,i={}){this.media=e,this.events=i,this.audioBooster=new k(e),U(e,!0);let r=l(c(t),.07,16);if(this.desiredRate=r,this.observedRate=e.playbackRate,e.playbackRate!==r)try{e.playbackRate=r}catch{}this.bindEvents()}bindEvents(){let{signal:e}=this.abortController;this.media.addEventListener("ratechange",()=>{this.observedRate=this.media.playbackRate,this.events.onRateChange?.(this,this.observedRate,this.lastSource)},{signal:e});let t=["play","pause","timeupdate","loadedmetadata","emptied"];for(let i of t)this.media.addEventListener(i,()=>{this.events.onStateChange?.(this)},{signal:e})}setRate(e,t="extension"){if(this.destroyed)return;let i=l(c(e),.07,16);this.desiredRate=i,this.lastSource=t,this.lastInteractionAt=Date.now();try{this.media.playbackRate!==i&&(this.media.playbackRate=i)}catch(r){console.warn("[Velocity] Failed to set playbackRate on media:",r)}}increaseRate(e=.1){this.setRate(this.desiredRate+e,"extension")}decreaseRate(e=.1){this.setRate(this.desiredRate-e,"extension")}resetRate(e=1){let t=l(c(e),.07,16);if(this.desiredRate===t){if(this.previousRateBeforeReset!==null){let i=this.previousRateBeforeReset;this.previousRateBeforeReset=null,this.setRate(i,"extension");return}}else this.previousRateBeforeReset=this.desiredRate;this.setRate(t,"extension")}seekBy(e){if(this.destroyed||!Number.isFinite(e)||q(this.media))return;this.lastInteractionAt=Date.now();let t=Number.isFinite(this.media.duration)?this.media.duration:1/0,i=l(this.media.currentTime+e,0,t);try{this.media.currentTime=i}catch(r){console.warn("[Velocity] Failed to seek media:",r)}}setMarker(){this.destroyed||(this.markerTime=this.media.currentTime,this.lastInteractionAt=Date.now())}jumpToMarker(){if(this.destroyed||this.markerTime===null)return;this.lastInteractionAt=Date.now();let e=this.media.currentTime;if(this.positionBeforeJump!==null&&Math.abs(e-this.markerTime)<.5){let t=this.positionBeforeJump;this.positionBeforeJump=null;try{this.media.currentTime=t}catch(i){console.warn("[Velocity] Failed to return from marker:",i)}return}this.positionBeforeJump=e;try{this.media.currentTime=this.markerTime}catch(t){console.warn("[Velocity] Failed to jump to marker:",t)}}togglePreferredRate(e=1.8){if(this.destroyed)return;let t=l(c(e),.07,16);if(this.desiredRate===t){let i=this.previousRateBeforePreferred??1;this.previousRateBeforePreferred=null,this.setRate(i,"extension")}else this.previousRateBeforePreferred=this.desiredRate,this.setRate(t,"extension")}getAudioGain(){return this.audioBooster.getGain()}setAudioGain(e){this.destroyed||(this.lastInteractionAt=Date.now(),this.audioBooster.setGain(e))}increaseAudioGain(e=.2){this.setAudioGain(this.audioBooster.getGain()+e)}decreaseAudioGain(e=.2){this.setAudioGain(this.audioBooster.getGain()-e)}togglePitch(){return this.destroyed?this.preservesPitch:(this.lastInteractionAt=Date.now(),this.preservesPitch=!this.preservesPitch,U(this.media,this.preservesPitch),this.preservesPitch)}async togglePictureInPicture(){if(this.destroyed||(this.lastInteractionAt=Date.now(),!(this.media instanceof HTMLVideoElement)))return!1;try{return document.pictureInPictureElement===this.media?(await document.exitPictureInPicture(),!1):(await this.media.requestPictureInPicture(),!0)}catch(e){return console.warn("[Velocity] PiP request failed:",e),!1}}toggleSilenceSkip(e){if(this.destroyed)return this.silenceSkipEnabled;if(this.lastInteractionAt=Date.now(),this.silenceSkipEnabled=e??!this.silenceSkipEnabled,this.silenceSkipEnabled)this.silenceDetector||(this.silenceDetector=new A(this.media,{onSilenceChange:t=>{if(!(this.destroyed||!this.silenceSkipEnabled)){if(t)this.rateBeforeSilence===null&&(this.rateBeforeSilence=this.desiredRate),this.setRate(Math.max(this.desiredRate,3),"extension");else if(this.rateBeforeSilence!==null){let i=this.rateBeforeSilence;this.rateBeforeSilence=null,this.setRate(i,"extension")}}}})),this.silenceDetector.start();else if(this.silenceDetector?.stop(),this.rateBeforeSilence!==null){let t=this.rateBeforeSilence;this.rateBeforeSilence=null,this.setRate(t,"extension")}return this.silenceSkipEnabled}destroy(){this.destroyed||(this.destroyed=!0,this.abortController.abort(),this.audioBooster.destroy(),this.silenceDetector?.destroy(),this.events.onDestroy?.(this))}};var D=class{mediaMap=new WeakMap;controllers=new Set;events;constructor(e={}){this.events=e}register(e,t=1,i={}){let r=this.mediaMap.get(e);if(r&&!r.destroyed)return r;let n=new T(e,t,{...i,onDestroy:s=>{this.controllers.delete(s),i.onDestroy?.(s),this.events.onUnregistered?.(s)}});return this.mediaMap.set(e,n),this.controllers.add(n),this.events.onRegistered?.(n),n}get(e){let t=this.mediaMap.get(e);if(t?.destroyed){this.controllers.delete(t);return}return t}unregister(e){let t=this.mediaMap.get(e);t&&(t.destroy(),this.controllers.delete(t))}getAll(){let e=[];for(let t of this.controllers)t.destroyed?this.controllers.delete(t):e.push(t);return e}clear(){for(let e of this.controllers)e.destroy();this.controllers.clear()}};var P=class{registry;constructor(e){this.registry=e}getActiveController(){let e=this.registry.getAll();if(e.length===0)return null;if(e.length===1)return e[0];let t=null,i=-1/0,r=Date.now();for(let n of e){if(n.destroyed)continue;let s=n.media,a=0;s.isConnected||(a-=1e4),!s.paused&&!s.ended&&s.readyState>1&&(a+=1e3);let h=r-n.lastInteractionAt;h<1e4&&(a+=3e3-Math.floor(h/4));try{let m=s.getBoundingClientRect();if(m.width>0&&m.height>0){let v=m.width*m.height,y=Math.min(2e3,Math.floor(v/500));a+=y}}catch{}(s.muted||s.volume===0)&&(a-=500),a>i&&(i=a,t=n)}return t??e[0]??null}};var L=class{selectionManager;callbacks;constructor(e,t={}){this.selectionManager=e,this.callbacks=t}execute(e){if(e.type==="overlay.toggle")return this.callbacks.onOverlayToggle?.(),this.callbacks.onActionExecuted?.(e,null),!0;let t=this.selectionManager.getActiveController();if(!t||t.destroyed)return!1;switch(e.type){case"speed.increase":t.increaseRate(e.step??.1);break;case"speed.decrease":t.decreaseRate(e.step??.1);break;case"speed.set":t.setRate(e.value,"extension");break;case"speed.reset":t.resetRate(e.target??1);break;case"speed.preferred.toggle":t.togglePreferredRate(e.preferred??1.8);break;case"seek.relative":t.seekBy(e.seconds);break;case"marker.set":t.setMarker();break;case"marker.jump":t.jumpToMarker();break;case"audio.boost.increase":t.increaseAudioGain(e.step??.2);break;case"audio.boost.decrease":t.decreaseAudioGain(e.step??.2);break;case"audio.boost.set":t.setAudioGain(e.value);break;case"pitch.toggle":t.togglePitch();break;case"pip.toggle":t.togglePictureInPicture().catch(()=>{});break;case"silence.skip.toggle":t.toggleSilenceSkip(e.enabled);break;default:return!1}return this.callbacks.onActionExecuted?.(e,t),!0}};var H=class{lastTrustedInteractionAt=0;abortController=null;constructor(){this.attach()}attach(e=document){this.detach(),this.abortController=new AbortController;let{signal:t}=this.abortController,i=["pointerdown","pointerup","click","touchstart","touchend","keydown"];for(let r of i)try{e.addEventListener(r,n=>{n.isTrusted&&this.recordInteraction()},{capture:!0,passive:!0,signal:t})}catch{}}recordInteraction(){this.lastTrustedInteractionAt=Date.now()}isRecentInteraction(e=3e3){return Date.now()-this.lastTrustedInteractionAt<=e}getLastInteractionTime(){return this.lastTrustedInteractionAt}detach(){this.abortController&&(this.abortController.abort(),this.abortController=null)}};var N=class{observer=null;callbacks;isObserving=!1;constructor(e){this.callbacks=e}observe(e=document){if(!this.isObserving){this.isObserving=!0,this.discoverMediaInSubtree(e),this.observer=new MutationObserver(t=>{for(let i of t){for(let r=0;r<i.addedNodes.length;r++){let n=i.addedNodes[r];this.discoverMediaInSubtree(n)}if(this.callbacks.onMediaRemoved)for(let r=0;r<i.removedNodes.length;r++){let n=i.removedNodes[r];this.handleRemovedSubtree(n)}}});try{this.observer.observe(e,{childList:!0,subtree:!0})}catch(t){console.warn("[Velocity] MutationObserver failed to attach:",t)}}}discoverMediaInSubtree(e){if(M(e)&&this.callbacks.onMediaFound(e),e instanceof Element||e instanceof Document||e instanceof DocumentFragment){let t=e.querySelectorAll("video, audio");for(let r=0;r<t.length;r++){let n=t[r];M(n)&&this.callbacks.onMediaFound(n)}let i=e.querySelectorAll("*");for(let r=0;r<i.length;r++){let n=i[r];n.shadowRoot&&this.discoverMediaInSubtree(n.shadowRoot)}}e instanceof Element&&e.shadowRoot&&this.discoverMediaInSubtree(e.shadowRoot)}handleRemovedSubtree(e){if(M(e)&&this.callbacks.onMediaRemoved?.(e),e instanceof Element||e instanceof DocumentFragment){let t=e.querySelectorAll("video, audio");for(let i=0;i<t.length;i++){let r=t[i];M(r)&&this.callbacks.onMediaRemoved?.(r)}}e instanceof Element&&e.shadowRoot&&this.handleRemovedSubtree(e.shadowRoot)}disconnect(){this.isObserving&&(this.isObserving=!1,this.observer?.disconnect(),this.observer=null)}};var B=class{desiredRate;fightAutomaticResets;consecutiveCorrections=0;windowStart=0;circuitBreakerTripped=!1;constructor(e=1,t=!0){this.desiredRate=c(e),this.fightAutomaticResets=t}setDesiredRate(e){e<.07||!Number.isFinite(e)||(this.desiredRate=c(e),this.consecutiveCorrections=0,this.circuitBreakerTripped=!1)}observeRateChange(e,t,i=!1,r){if(e<.07||!Number.isFinite(e))return{type:"ignore"};let n=c(e);if(r==="temporary-hold")return this.consecutiveCorrections=0,this.circuitBreakerTripped=!1,{type:"accept",rate:n,source:"temporary-hold"};if(i)return this.desiredRate=n,this.consecutiveCorrections=0,this.circuitBreakerTripped=!1,{type:"accept",rate:this.desiredRate,source:"extension"};if(n===this.desiredRate)return this.consecutiveCorrections=0,{type:"accept",rate:this.desiredRate,source:"extension"};if(t)return this.desiredRate=n,this.consecutiveCorrections=0,this.circuitBreakerTripped=!1,{type:"accept",rate:this.desiredRate,source:"site-user"};if(!this.fightAutomaticResets)return{type:"accept",rate:n,source:"site-automatic"};let s=Date.now();return s-this.windowStart>1e3&&(this.windowStart=s,this.consecutiveCorrections=0,this.circuitBreakerTripped=!1),this.consecutiveCorrections++,this.consecutiveCorrections>=6?(this.circuitBreakerTripped=!0,console.warn(`[Velocity] Speed oscillation circuit breaker tripped (${this.consecutiveCorrections} corrections in window).`),{type:"ignore"}):{type:"restore",rate:this.desiredRate,source:"restored"}}resetCircuitBreaker(){this.consecutiveCorrections=0,this.circuitBreakerTripped=!1,this.windowStart=0}};var I=class{element;getContainer;callbacks;abortController=new AbortController;isDragging=!1;startPointerX=0;startPointerY=0;startElemX=0;startElemY=0;currentPos;constructor(e,t,i={xRatio:.02,yRatio:.02},r={}){this.element=e,this.getContainer=t,this.currentPos={xRatio:l(i.xRatio,0,.95),yRatio:l(i.yRatio,0,.95)},this.callbacks=r,this.bindEvents()}getPosition(){return{...this.currentPos}}setPosition(e){this.currentPos={xRatio:l(e.xRatio,0,.95),yRatio:l(e.yRatio,0,.95)}}bindEvents(){let{signal:e}=this.abortController;this.element.addEventListener("pointerdown",i=>{if(i.button!==0)return;let r=i.target;if(r&&(r.tagName.toLowerCase()==="button"||r.closest("button")))return;let n=this.getContainer();if(!n)return;this.isDragging=!0,this.startPointerX=i.clientX,this.startPointerY=i.clientY;let s=n.getBoundingClientRect(),a=this.element.getBoundingClientRect();this.startElemX=a.left-s.left,this.startElemY=a.top-s.top;try{this.element.setPointerCapture(i.pointerId)}catch{}i.preventDefault(),i.stopPropagation(),this.callbacks.onDragStart?.()},{signal:e}),this.element.addEventListener("pointermove",i=>{if(!this.isDragging)return;let r=this.getContainer();if(!r)return;let n=r.getBoundingClientRect(),s=this.element.getBoundingClientRect(),a=Math.max(n.width-s.width,1),h=Math.max(n.height-s.height,1),m=i.clientX-this.startPointerX,v=i.clientY-this.startPointerY,y=this.startElemX+m,p=this.startElemY+v,X=l(y,0,a),Q=l(p,0,h);this.currentPos={xRatio:l(X/n.width,0,.95),yRatio:l(Q/n.height,0,.95)},this.callbacks.onDrag?.(this.currentPos)},{signal:e});let t=i=>{if(this.isDragging){this.isDragging=!1;try{this.element.hasPointerCapture(i.pointerId)&&this.element.releasePointerCapture(i.pointerId)}catch{}this.callbacks.onDragEnd?.(this.currentPos)}};this.element.addEventListener("pointerup",t,{signal:e}),this.element.addEventListener("pointercancel",t,{signal:e})}destroy(){this.abortController.abort(),this.isDragging=!1}};var re=`
:host {
  all: initial !important;
  display: block !important;
  position: absolute !important;
  z-index: 2147483647 !important;
  font-family: sans-serif !important;
  font-size: 13px !important;
  line-height: 1.8em !important;
  user-select: none !important;
  -webkit-user-select: none !important;
  pointer-events: auto !important;
  touch-action: none !important;
}

:host([data-hidden="true"]) {
  display: none !important;
}

#controller {
  display: inline-flex;
  align-items: center;
  position: absolute;
  top: 0;
  left: 0;
  background: black;
  color: white;
  border-radius: 6px;
  padding: 4px;
  margin: 10px 10px 10px 15px;
  cursor: default;
  white-space: nowrap;
  opacity: 0.3;
  box-sizing: border-box;
  transition: opacity 0.2s ease;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
}

#controller:hover,
#controller.expanded,
#controller.dragging {
  opacity: 0.7 !important;
}

#controller.dragging {
  cursor: grabbing;
}

.draggable {
  cursor: grab;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 2.8em;
  height: 1.4em;
  text-align: center;
  vertical-align: middle;
  box-sizing: border-box;
  touch-action: none;
  font-family: sans-serif;
  font-size: 14px;
  font-weight: 600;
  color: #ffffff;
  padding: 0 2px;
  transition: margin-right 0.2s ease;
}

.draggable:active {
  cursor: grabbing;
}

#controller:hover > .draggable,
#controller.expanded > .draggable {
  margin-right: 0.5em;
}

#controls {
  display: none;
  vertical-align: middle;
  align-items: center;
  gap: 2px;
}

#controller:hover #controls,
#controller.expanded #controls,
#controller.dragging #controls {
  display: inline-flex;
}

button.ctrl-btn {
  opacity: 1;
  cursor: pointer;
  color: black;
  background: white;
  font-weight: normal;
  border-radius: 5px;
  padding: 1px 5px 2px 5px;
  font-size: 13px;
  line-height: 16px;
  border: 0px solid white;
  font-family: "Lucida Console", Monaco, monospace;
  margin: 0px 2px;
  transition: background 0.15s ease, color 0.15s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
}

button.ctrl-btn:focus {
  outline: 0;
}

button.ctrl-btn:hover {
  opacity: 1;
  background: #2196f3;
  color: #ffffff;
}

button.ctrl-btn:active {
  background: #1976d2;
  color: #ffffff;
  font-weight: bold;
}

button.ctrl-btn.rw {
  opacity: 0.65;
}

button.ctrl-btn.rw:hover {
  opacity: 1;
}

button.ctrl-btn.close-btn {
  font-size: 14px;
  padding: 1px 6px;
  opacity: 0.75;
}

button.ctrl-btn.close-btn:hover {
  background: #e53935;
  color: #ffffff;
  opacity: 1;
}

.rate-badge.highlight {
  color: #64b5f6 !important;
  text-shadow: 0 0 8px rgba(100, 181, 246, 0.9) !important;
}
`,S=class extends HTMLElement{shadow;pillElem;rateBadge;controlsGroup;dragHandler=null;controller=null;resizeObserver=null;currentPosition={xRatio:.02,yRatio:.02};highlightTimer=null;hoverStart=0;lastWheelStep=0;constructor(){super(),this.shadow=this.attachShadow({mode:"closed"}),this.render()}render(){let e=document.createElement("style");e.textContent=re,this.pillElem=document.createElement("div"),this.pillElem.id="controller",this.pillElem.className="velocity-controller",this.rateBadge=document.createElement("span"),this.rateBadge.className="draggable rate-badge",this.rateBadge.setAttribute("data-action","drag"),this.rateBadge.setAttribute("aria-label","Playback speed. Double click to reset to 1.00"),this.rateBadge.textContent="1.00",this.controlsGroup=document.createElement("span"),this.controlsGroup.id="controls",this.controlsGroup.className="controls-group";let t=document.createElement("button");t.className="ctrl-btn rw",t.setAttribute("data-action","rewind"),t.setAttribute("aria-label","Rewind 10 seconds"),t.textContent="\xAB";let i=document.createElement("button");i.className="ctrl-btn",i.setAttribute("data-action","slower"),i.setAttribute("aria-label","Decrease playback speed"),i.textContent="\u2212";let r=document.createElement("button");r.className="ctrl-btn",r.setAttribute("data-action","faster"),r.setAttribute("aria-label","Increase playback speed"),r.textContent="+";let n=document.createElement("button");n.className="ctrl-btn rw",n.setAttribute("data-action","advance"),n.setAttribute("aria-label","Advance 10 seconds"),n.textContent="\xBB";let s=document.createElement("button");s.className="ctrl-btn close-btn",s.setAttribute("data-action","close"),s.setAttribute("aria-label","Hide controller (Press V to toggle)"),s.textContent="\xD7",this.controlsGroup.appendChild(t),this.controlsGroup.appendChild(i),this.controlsGroup.appendChild(r),this.controlsGroup.appendChild(n),this.controlsGroup.appendChild(s),this.pillElem.appendChild(this.rateBadge),this.pillElem.appendChild(this.controlsGroup),this.shadow.appendChild(e),this.shadow.appendChild(this.pillElem),this.setupInteractions()}setupInteractions(){this.pillElem.addEventListener("click",r=>{r.stopPropagation();let n=r.target;if(!n||!this.controller)return;let s=n.getAttribute("data-action");if(!(!s||s==="drag"))switch(r.preventDefault(),s){case"rewind":this.controller.seekBy(-10);break;case"slower":this.controller.decreaseRate();break;case"faster":this.controller.increaseRate();break;case"advance":this.controller.seekBy(10);break;case"close":this.setVisible(!1);break}}),this.pillElem.addEventListener("mousedown",r=>{r.stopPropagation()}),this.rateBadge.addEventListener("dblclick",r=>{r.stopPropagation(),r.preventDefault(),this.controller?.resetRate()});let e=300,t=50,i=120;this.pillElem.addEventListener("mouseenter",()=>{this.hoverStart=performance.now()}),this.pillElem.addEventListener("mouseleave",()=>{this.hoverStart=0}),this.pillElem.addEventListener("wheel",r=>{if(r.ctrlKey||performance.now()-this.hoverStart<e||r.deltaMode===WheelEvent.DOM_DELTA_PIXEL&&Math.abs(r.deltaY)<t)return;let n=performance.now();if(n-this.lastWheelStep<i){r.preventDefault(),r.stopPropagation();return}this.lastWheelStep=n,r.preventDefault(),r.stopPropagation(),this.controller&&(r.deltaY<0?this.controller.increaseRate():this.controller.decreaseRate())},{passive:!1})}attachController(e,t,i={xRatio:.02,yRatio:.02}){this.controller=e,this.currentPosition=i,this.updateRateDisplay(e.desiredRate),this.dragHandler?.destroy(),this.dragHandler=new I(this.pillElem,()=>t,i,{onDragStart:()=>{this.pillElem.classList.add("dragging")},onDrag:r=>{this.currentPosition=r,this.updatePositionStyles(t)},onDragEnd:r=>{this.pillElem.classList.remove("dragging"),this.currentPosition=r,this.updatePositionStyles(t)}}),this.updatePositionStyles(t);try{this.resizeObserver?.disconnect(),this.resizeObserver=new ResizeObserver(()=>{this.updatePositionStyles(t)}),this.resizeObserver.observe(t)}catch{}}updateRateDisplay(e){this.rateBadge&&(this.rateBadge.textContent=w(e),this.rateBadge.classList.add("highlight"),clearTimeout(this.highlightTimer??void 0),this.highlightTimer=window.setTimeout(()=>{this.rateBadge.classList.remove("highlight")},500))}updatePositionStyles(e){let t=e.getBoundingClientRect();if(t.width<=0||t.height<=0)return;let i=Math.round(this.currentPosition.xRatio*t.width),r=Math.round(this.currentPosition.yRatio*t.height);this.style.left=`${i}px`,this.style.top=`${r}px`}setVisible(e){e?this.removeAttribute("data-hidden"):this.setAttribute("data-hidden","true")}destroy(){clearTimeout(this.highlightTimer??void 0),this.dragHandler?.destroy(),this.dragHandler=null,this.resizeObserver?.disconnect(),this.resizeObserver=null,this.controller=null,this.remove()}};function Y(){let o=typeof window<"u"?window.customElements:typeof customElements<"u"?customElements:null;o&&!o.get("velocity-controller")&&o.define("velocity-controller",S)}Y();var ne=`
:host {
  all: initial !important;
  position: absolute !important;
  top: 12% !important;
  left: 50% !important;
  transform: translate(-50%, -10px) !important;
  z-index: 2147483647 !important;
  pointer-events: none !important;
  display: block !important;
  visibility: hidden !important;
  opacity: 0 !important;
  transition: opacity 0.18s cubic-bezier(0.16, 1, 0.3, 1), transform 0.18s cubic-bezier(0.16, 1, 0.3, 1), visibility 0.18s !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
}
:host(.visible) {
  visibility: visible !important;
  opacity: 1 !important;
  transform: translate(-50%, 0) !important;
}
.toast-badge {
  background: rgba(10, 12, 16, 0.88) !important;
  backdrop-filter: blur(16px) !important;
  -webkit-backdrop-filter: blur(16px) !important;
  color: #f8fafc !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
  font-size: 14px !important;
  font-weight: 700 !important;
  line-height: 1.4 !important;
  padding: 8px 18px !important;
  border-radius: 9999px !important;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(255, 255, 255, 0.14) !important;
  letter-spacing: 0.2px !important;
  display: inline-flex !important;
  align-items: center !important;
  gap: 8px !important;
  white-space: nowrap !important;
  user-select: none !important;
  -webkit-user-select: none !important;
}
.toast-icon {
  font-size: 14px !important;
  color: #38e1ff !important;
  display: inline-block !important;
  text-shadow: 0 0 8px rgba(56, 225, 255, 0.4) !important;
}
`,R=class extends HTMLElement{shadow;badge;iconElem;textElem;hideTimer=null;constructor(){super(),this.shadow=this.attachShadow({mode:"closed"});let e=document.createElement("style");e.textContent=ne,this.badge=document.createElement("div"),this.badge.className="toast-badge",this.iconElem=document.createElement("span"),this.iconElem.className="toast-icon",this.textElem=document.createElement("span"),this.badge.appendChild(this.iconElem),this.badge.appendChild(this.textElem),this.shadow.appendChild(e),this.shadow.appendChild(this.badge)}show(e,t="\u26A1",i=900){this.hideTimer!==null&&(window.clearTimeout(this.hideTimer),this.hideTimer=null),this.iconElem.textContent=t,this.textElem.textContent=e,this.classList.add("visible"),this.hideTimer=window.setTimeout(()=>{this.classList.remove("visible"),this.hideTimer=null},i)}destroy(){this.hideTimer!==null&&(window.clearTimeout(this.hideTimer),this.hideTimer=null),this.remove()}};function J(){let o=window.customElements;o&&!o.get("velocity-hud-toast")&&o.define("velocity-hud-toast",R)}var O=class{callback;abortController=new AbortController;constructor(e){this.callback=e,this.bindEvents()}bindEvents(){let{signal:e}=this.abortController,t=()=>{let i=null;if(document.fullscreenElement instanceof Element)i=document.fullscreenElement;else if("webkitFullscreenElement"in document){let n=document.webkitFullscreenElement;n instanceof Element&&(i=n)}let r=i!==null;this.callback(r,i)};document.addEventListener("fullscreenchange",t,{signal:e}),document.addEventListener("webkitfullscreenchange",t,{signal:e})}destroy(){this.abortController.abort()}};var _=class{handlers=[];register(e){this.handlers.push(e)}findHandler(e){for(let t of this.handlers)if(t.matches(e))return t;return null}getAll(){return[...this.handlers]}clear(){for(let e of this.handlers)e.cleanup?.();this.handlers=[]}};var F=class{name="YouTube";abortController=null;isPointerHolding=!1;matches(e){return b("youtube.com",e.hostname)}getMediaContainer(e){let t=e.closest("#movie_player, .html5-video-player, ytd-player, .ytd-player");return t instanceof HTMLElement?t:e.parentElement||e.parentNode}onMediaAdded(e,t){this.abortController&&this.abortController.abort(),this.abortController=new AbortController;let{signal:i}=this.abortController;(this.getMediaContainer(e)??e).addEventListener("pointerdown",s=>{s instanceof MouseEvent&&s.button!==0||(this.isPointerHolding=!0)},{signal:i,passive:!0});let n=()=>{this.isPointerHolding=!1};window.addEventListener("pointerup",n,{signal:i,passive:!0}),window.addEventListener("pointercancel",n,{signal:i,passive:!0}),window.addEventListener("yt-navigate-finish",()=>{try{e.isConnected&&!t.destroyed&&setTimeout(()=>{e.playbackRate!==t.desiredRate&&t.setRate(t.desiredRate,"restored")},100)}catch{}},{signal:i})}classifyRateChange(e,t){if(this.isPointerHolding&&t.playbackRate===2)return"temporary-hold"}cleanup(){this.abortController&&(this.abortController.abort(),this.abortController=null)}};var V=class{name="Netflix";matches(e){return b("netflix.com",e.hostname)}getMediaContainer(e){let t=e.closest(".watch-video, .AkiraPlayer, .sizing-wrapper, .nfp");return t instanceof HTMLElement?t:e.parentElement||e.parentNode}};var K=class{settings=$;siteRuleEngine=new x(this.settings);mediaRegistry=new D;selectionManager=new P(this.mediaRegistry);intentClassifier=new H;actionHandler;shortcutManager;mediaObserver;fullscreenObserver;siteHandlerRegistry=new _;arbiters=new WeakMap;overlays=new WeakMap;toasts=new WeakMap;constructor(){Y(),J(),this.siteHandlerRegistry.register(new F),this.siteHandlerRegistry.register(new V),this.actionHandler=new L(this.selectionManager,{onOverlayToggle:()=>this.toggleAllOverlays(),onActionExecuted:(e,t)=>this.handleActionExecuted(e,t)}),this.shortcutManager=new C(this.actionHandler,this.settings.shortcuts),this.mediaObserver=new N({onMediaFound:e=>this.handleMediaFound(e),onMediaRemoved:e=>this.handleMediaRemoved(e)}),this.fullscreenObserver=new O((e,t)=>{this.handleFullscreenChange(e,t)})}init(){this.bindBridgeListeners(),this.shortcutManager.attach(),this.mediaObserver.observe(),window.dispatchEvent(new CustomEvent("velocity:main:ready"))}bindBridgeListeners(){window.addEventListener("velocity:settings:init",e=>{let t=e;t.detail&&this.applySettings(t.detail)}),window.addEventListener("velocity:settings:update",e=>{let t=e;t.detail&&this.applySettings(t.detail)}),window.addEventListener("velocity:action:execute",e=>{let t=e;t.detail&&this.actionHandler.execute(t.detail)}),window.addEventListener("velocity:status:query",e=>{let i=e.detail?.nonce;if(!i)return;let r=this.selectionManager.getActiveController(),n=this.mediaRegistry.getAll();window.dispatchEvent(new CustomEvent(`velocity:status:reply:${i}`,{detail:{hasMedia:n.length>0,mediaCount:n.length,activeRate:r?r.desiredRate:this.settings.defaultSpeed,activeMuted:r?r.media.muted:!1,activePaused:r?r.media.paused:!0}}))})}applySettings(e){this.settings=e,this.siteRuleEngine.updateSettings(e),this.shortcutManager.setShortcuts(e.shortcuts);let t=this.siteRuleEngine.resolveSiteConfig(window.location);for(let i of this.mediaRegistry.getAll()){let r=this.arbiters.get(i.media);r&&(r.fightAutomaticResets=e.compatibility.fightAutomaticRateReset);let n=this.overlays.get(i.media);n&&n.setVisible(t.overlayEnabled&&!this.settings.startHidden)}}handleActionExecuted(e,t){if(!t)return;let i=this.toasts.get(t.media);if(i)switch(e.type){case"speed.increase":case"speed.decrease":case"speed.set":case"speed.reset":case"speed.preferred.toggle":{let r=w(t.desiredRate);i.show(`${r}\xD7`,"");break}case"seek.relative":{let r=e.seconds>=0?"+":"";i.show(`${r}${e.seconds}s`,"\u23E9");break}case"marker.set":{i.show("Marker Set","\u{1F4CD}");break}case"marker.jump":{i.show("Jumped to Marker","\u{1F3AF}");break}case"audio.boost.increase":case"audio.boost.decrease":case"audio.boost.set":{let r=Math.round(t.getAudioGain()*100);i.show(`Gain: ${r}%`,"\u{1F50A}");break}case"pitch.toggle":{let r=t?t.preservesPitch:!0;i.show(r?"Pitch Preserved":"Natural Pitch","\u{1F3B5}");break}case"pip.toggle":i.show("Picture-in-Picture","\u{1F5BC}\uFE0F");break;case"silence.skip.toggle":{let r=t?t.silenceSkipEnabled:!1;i.show(r?"Silence Skip On":"Silence Skip Off","\u23E9");break}}}handleMediaFound(e){if(this.mediaRegistry.get(e)||e.tagName.toLowerCase()==="audio"&&this.settings.audioBoolean===!1)return;let t=this.siteRuleEngine.resolveSiteConfig(window.location);if(!t.enabled)return;let i=new B(t.initialSpeed,this.settings.compatibility.fightAutomaticRateReset);this.arbiters.set(e,i);let r=this.siteHandlerRegistry.findHandler(window.location),n=this.mediaRegistry.register(e,t.initialSpeed,{onRateChange:(s,a,h)=>{let m=r?.classifyRateChange?.(new Event("ratechange"),s.media),v=this.intentClassifier.isRecentInteraction(),y=h==="extension",p=i.observeRateChange(a,v,y,m);p.type==="restore"?s.setRate(p.rate,"restored"):p.type==="accept"&&t.rememberSpeed&&p.source!=="site-automatic"&&p.source!=="temporary-hold"&&p.rate>=.07&&window.dispatchEvent(new CustomEvent("velocity:storage:save-last-speed",{detail:{speed:p.rate,domain:window.location.hostname}})),this.overlays.get(e)?.updateRateDisplay(s.desiredRate)},onDestroy:s=>{this.overlays.get(s.media)?.destroy(),this.toasts.get(s.media)?.destroy(),this.overlays.delete(s.media),this.toasts.delete(s.media),this.arbiters.delete(s.media)}});if(r?.onMediaAdded?.(e,n),this.mountToast(e),t.overlayEnabled&&this.isEligibleForOverlay(e)){let s=this.mountOverlay(e,n);this.settings.startHidden&&s&&s.setVisible(!1)}}handleMediaRemoved(e){let t=this.mediaRegistry.get(e);t&&t.destroy()}isEligibleForOverlay(e){if(e.tagName.toLowerCase()==="audio")return!1;let t=e.getBoundingClientRect();return!(t.width>0&&t.width<160&&t.height>0&&t.height<90)}mountOverlay(e,t){if(this.overlays.has(e))return this.overlays.get(e)??null;let r=this.siteHandlerRegistry.findHandler(window.location)?.getMediaContainer?.(e)||e.parentElement||e.parentNode;if(!r)return null;window.getComputedStyle(r).position==="static"&&(r.style.position="relative");let s=new S;return r.appendChild(s),s.attachController(t,r,this.settings.overlay.position),this.overlays.set(e,s),s}mountToast(e){if(this.toasts.has(e))return this.toasts.get(e)??null;let i=this.siteHandlerRegistry.findHandler(window.location)?.getMediaContainer?.(e)||e.parentElement||e.parentNode;if(!i)return null;let r=new R;return i.appendChild(r),this.toasts.set(e,r),r}toggleAllOverlays(){for(let e of this.mediaRegistry.getAll()){let t=this.overlays.get(e.media);if(t){let i=t.getAttribute("data-hidden")==="true";t.setVisible(i)}}}handleFullscreenChange(e,t){if(t)for(let i of this.mediaRegistry.getAll()){let r=this.overlays.get(i.media);r&&i.media.parentElement&&r.updatePositionStyles(i.media.parentElement)}}},ae=new K;ae.init();})();
